test = {   'name': 'q2_1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> 1 <= characters_q1 <= 5\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> characters_q1 == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
