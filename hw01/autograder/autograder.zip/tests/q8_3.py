test = {'name': 'q8_3', 'points': 1, 'suites': [{'cases': [{'code': '>>> regrade == 2\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
