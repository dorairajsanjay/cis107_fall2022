test = {   'name': 'q2_5',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> sum_of_birth_years == 5433\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
