test = {   'name': 'q3_5',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> round(sum(celsius_temperature_ranges)) == 768487.0\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> len(celsius_temperature_ranges) == 65000\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> celsius_temperature_ranges.item(1) == 10.0\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
