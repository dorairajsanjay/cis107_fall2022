test = {   'name': 'q5_2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Hint: If you are getting 47 as your answer, you might be computing the biggest change rather than biggest decrease!;\n'
                                               '>>> biggest_decrease != 47\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> # Hint: biggest decrease is above 30, but not 47;\n>>> 30 <= biggest_decrease < 47\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> biggest_decrease == 45\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
