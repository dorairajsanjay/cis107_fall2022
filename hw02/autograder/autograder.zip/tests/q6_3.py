test = {   'name': 'q6_3',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> all_different in {True, False}\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> all_different == False\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
