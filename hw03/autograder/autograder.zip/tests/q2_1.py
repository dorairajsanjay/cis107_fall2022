test = {   'name': 'q2_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 0 < us_birth_rate < 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> us_birth_rate == sum(pop.column('BIRTHS'))/sum(pop.column('2015')) \nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
