test = {   'name': 'q2_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 0 <= less_than_west_births <= 52\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> less_than_west_births == 7\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
