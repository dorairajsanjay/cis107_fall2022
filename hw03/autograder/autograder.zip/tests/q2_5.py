test = {   'name': 'q2_5',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(visualization) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 1 <= visualization <= 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> visualization == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
