test = {   'name': 'q2_6',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> round(t_chance, 4) == .0781\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
