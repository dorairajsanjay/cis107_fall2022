test = {   'name': 'q5_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> statistic_choice in [1, 2, 3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> statistic_choice == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
