test = {   'name': 'q1_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(percentages_in_resamples()) == 2500\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.random.seed(123);\n>>> np.isclose(percentages_in_resamples().item(10), 51, 3)\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.random.seed(123);\n>>> np.isclose(percentages_in_resamples().item(10), 50, 3)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
