test = {   'name': 'q2_4',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> 1 <= restaurants_tied <= 3\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> restaurants_tied == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
