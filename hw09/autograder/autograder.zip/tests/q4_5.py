test = {   'name': 'q4_5',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(resampled_means_variability) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 10.2 <= resampled_means_variability <= 10.8\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
