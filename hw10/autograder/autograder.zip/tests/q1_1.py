test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(is_su) == bool\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> all([np.round(copy_number_mean, 2) == -0.19, np.round(copy_number_sd, 2) == 0.75, is_su == False])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
