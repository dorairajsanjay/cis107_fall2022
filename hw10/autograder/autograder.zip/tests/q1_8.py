test = {   'name': 'q1_8',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(parameters_change) == bool\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> parameters_change == True\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
