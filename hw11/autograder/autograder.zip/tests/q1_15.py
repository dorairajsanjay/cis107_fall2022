test = {   'name': 'q1_15',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> all([type(career_length_residual_corr) == int, type(salary_residual_corr) == int])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> career_length_residual_corr == 2 and salary_residual_corr == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
