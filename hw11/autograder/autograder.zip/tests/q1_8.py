test = {   'name': 'q1_8',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> # Correlation is a number between -1 and 1;\n>>> -1 <= pick_salary_correlation <= 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(pick_salary_correlation, 3)  == -0.281\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
