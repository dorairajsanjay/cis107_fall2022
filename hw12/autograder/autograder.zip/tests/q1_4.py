test = {   'name': 'q1_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(first_test) == str\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': ">>> sorted_coordinates = coordinates.sort('school');\n"
                                               ">>> classify(sorted_coordinates.row(85), 3, sorted_coordinates.take(np.arange(50, 100))) == 'Stanford'\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
