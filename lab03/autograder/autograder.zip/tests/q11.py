test = {   'name': 'q11',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> woman_asking == 'The woman asked:'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> gagarin_quote == \'"As a matter of fact, I have!"\'\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
