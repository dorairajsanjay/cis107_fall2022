test = {   'name': 'q234',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> round(sum_of_bills, 2) == 1795730.06\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
