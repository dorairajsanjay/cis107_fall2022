test = {   'name': 'q32',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> convenience_sample.num_columns == 11\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> convenience_sample.num_rows == 44\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
