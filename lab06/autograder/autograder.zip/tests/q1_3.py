test = {   'name': 'q1_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(valid_stat) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> int(sum(valid_stat)) == 2\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
