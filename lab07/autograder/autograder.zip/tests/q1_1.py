test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(ab_test_order) == 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> correct_order = make_array(5, 1, 3, 2, 4, 6);\n>>> all(correct_order == ab_test_order)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
