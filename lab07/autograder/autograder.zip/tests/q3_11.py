test = {   'name': 'q3_11',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(differences) == 5000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(np.average(differences)) < 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> all(differences == differences.item(0)) == False\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
