test = {   'name': 'q3_8',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(observed_difference, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(observed_difference, 3) == 0.607\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
