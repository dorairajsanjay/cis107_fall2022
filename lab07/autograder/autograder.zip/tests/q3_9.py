test = {   'name': 'q3_9',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> np.isclose(round(find_test_stat(change_in_death_rates, "Death Penalty", "Murder Rate"),3) - 0.607, 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
