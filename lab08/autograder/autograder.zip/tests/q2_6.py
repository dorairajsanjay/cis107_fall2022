test = {   'name': 'q2_6',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> set(pop_vs_sample) == set([3,4])\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
