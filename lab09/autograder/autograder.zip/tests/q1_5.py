test = {'name': 'q1_5', 'points': 1, 'suites': [{'cases': [{'code': '>>> correlation == 3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
