test = {   'name': 'q2_2',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> (18 + intercept*(-4)) / 201 >= 0.3\nFalse', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
