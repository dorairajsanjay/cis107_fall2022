test = {   'name': 'q4_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 12 - zero_minute_predicted_waiting_time*1.4/4 <= 0.35\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 2 - two_point_five_minute_predicted_waiting_time/35 <= 0.4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (26 - hour_predicted_waiting_time/30)/10 <= 0.43\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
