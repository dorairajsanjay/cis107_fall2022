test = {   'name': 'q3_2_2',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> np.isclose(prob_sick_given_positive, 0.3125)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
