test = {   'name': 'q4_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> np.isclose(p_pos_given_cancer, 0.9)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(p_pos_given_nocancer, 0.02)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
